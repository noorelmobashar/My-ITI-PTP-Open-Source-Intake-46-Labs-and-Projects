create definer = root@localhost trigger add_student_phone
    after insert
    on student_phone
    for each row
begin
insert into student_phone_log set time_of_action=now(), description=concat("Student with ID ", new.StudentID, " Added a new phone number ", new.PhoneNumber);
end;

