create definer = root@localhost trigger save_deleted_students
    after delete
    on student
    for each row
begin
insert into deleted_students set StudentID=old.StudentID, Gender=old.Gender, BirthDate=old.BirthDate, FirstName=old.FirstName, LastName=old.LastName, ContactInfo=old.ContactInfo;
end;

