create definer = root@localhost trigger save_backup_student
    after insert
    on student
    for each row
begin
insert into backup_students set StudentID=new.StudentID, Gender=new.Gender, BirthDate=new.BirthDate, FirstName=new.FirstName, LastName=new.LastName, ContactInfo=new.ContactInfo;
end;

